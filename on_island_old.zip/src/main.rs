#![feature(once_cell_try)]
#![feature(hash_map_macro)]
use std::io::stdout;

use crossterm::{
    execute,
    terminal::{LeaveAlternateScreen, disable_raw_mode},
};

use crate::app::App;
#[macro_use]
extern crate rust_i18n;

rust_i18n::i18n!("locales", fallback = ["zh"]);
pub mod config;

pub mod app;
pub mod item;
pub mod player;
pub mod utils;

fn main() -> std::io::Result<()> {
    let r = App::new().and_then(|mut app| app.run());
    execute!(stdout(), LeaveAlternateScreen)?;
    disable_raw_mode()?;
    r
}
