#[macro_export]
macro_rules! io_err {
    ($kind:ident, $e:expr) => {
        std::io::Error::new(std::io::ErrorKind::$kind, $e)
    };
}
