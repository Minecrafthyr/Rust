use std::{collections::HashMap, ops::Deref};

use serde_json::Value;

use crate::config::{cfg, item::ItemDef};
#[derive(Debug, PartialEq, Eq, Clone)]
pub struct Item {
    pub idx: usize,
    pub data: HashMap<&'static str, Value>,
}
impl Deref for Item {
    type Target = ItemDef;

    fn deref(&self) -> &Self::Target { &cfg().items[self.idx] }
}
pub struct ItemStack {
    pub item: Item,
    pub count: u64,
}
