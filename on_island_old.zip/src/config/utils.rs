use serde::{
    Deserialize, Deserializer, Serialize,
    de::{Error, MapAccess, Visitor},
};
use serde_json::Value;
#[derive(Debug, Clone, Copy, Serialize, Deserialize)]
#[serde(untagged)]
pub enum FloatProvider {
    Fixed(f64),
    Random { min: f64, max: f64 },
}
#[derive(Debug, Clone, Copy, Serialize)]
#[serde(untagged)]
pub enum UnsignedProvider {
    Fixed(u64),
    Range { min: u64, max: u64 },
}
struct UnsignedProviderVisitor;
impl<'de> Visitor<'de> for UnsignedProviderVisitor {
    type Value = UnsignedProvider;

    fn expecting(&self, formatter: &mut std::fmt::Formatter) -> std::fmt::Result {
        formatter.write_str("an unsigned number or range")
    }

    fn visit_u64<E>(self, v: u64) -> Result<Self::Value, E>
    where
        E: Error,
    {
        Ok(UnsignedProvider::Fixed(v))
    }

    fn visit_seq<A>(self, mut seq: A) -> Result<Self::Value, A::Error>
    where
        A: serde::de::SeqAccess<'de>,
    {
        let min =
            seq.next_element::<u64>()?.ok_or_else(|| A::Error::custom("missing min value"))?;
        let max =
            seq.next_element::<u64>()?.ok_or_else(|| A::Error::custom("missing max value"))?;
        if min >= max {
            return Err(A::Error::custom("min >= max?"));
        }
        Ok(UnsignedProvider::Range { min, max })
    }

    fn visit_map<A>(self, mut map: A) -> Result<Self::Value, A::Error>
    where
        A: MapAccess<'de>,
    {
        let mut min = None;
        let mut max = None;
        while let Some(key) = map.next_key::<String>()? {
            match key.as_str() {
            "min" => {
                if min.is_some() {
                    return Err(A::Error::custom("duplicate min value"));
                }
                min = Some(map.next_value()?);
            }
            "max" => {
                if max.is_some() {
                    return Err(A::Error::custom("duplicate max value"));
                }
                max = Some(map.next_value()?);
            }
            _ => return Err(A::Error::custom(format!("unexpected key: {}", key))),
            }
        }
        let min = min.ok_or_else(|| A::Error::custom("missing min value"))?;
        let max = max.ok_or_else(|| A::Error::custom("missing max value"))?;
        Ok(UnsignedProvider::Range { min, max })
    }
}

impl<'de> Deserialize<'de> for UnsignedProvider {
    fn deserialize<D>(deserializer: D) -> Result<Self, D::Error>
    where
        D: Deserializer<'de>,
    {
        deserializer.deserialize_any(UnsignedProviderVisitor)
    }
}

fn flatten_yaml_inner(value: Value, prefix: &str, result: &mut Vec<(String, Value)>) {
    match value {
    Value::Object(map) =>
        for (k, v) in map {
            let new_prefix =
                if prefix.is_empty() { k.to_string() } else { format!("{prefix}.{k}") };
            flatten_yaml_inner(v, &new_prefix, result);
        },
    other => {
        result.push((prefix.to_string(), other));
    }
    }
}
pub fn flatten_map(value: Value) -> Vec<(String, Value)> {
    let mut m = Vec::new();
    flatten_yaml_inner(value, "", &mut m);
    m
}
use std::str::FromStr;

use fixed::types::I0F64;
#[derive(Debug, Default, Clone, Copy)]
pub struct Chance(pub I0F64);
struct ChanceVisitor;
impl<'de> Visitor<'de> for ChanceVisitor {
    type Value = Chance;

    fn expecting(&self, formatter: &mut std::fmt::Formatter) -> std::fmt::Result {
        formatter.write_str("a string representing a fixed-point number")
    }

    fn visit_f64<E>(self, v: f64) -> Result<Self::Value, E>
    where
        E: Error,
    {
        Ok(Chance(I0F64::from_num(v)))
    }

    fn visit_str<E>(self, v: &str) -> Result<Self::Value, E>
    where
        E: Error,
    {
        if v.ends_with("%") {
            let num_str = &v[..v.len() - 1];
            let num = I0F64::from_str(num_str)
                .map_err(|e| E::custom(format!("invalid fixed-point number: {}", e)))?;
            Ok(Chance(num / I0F64::from_num(100)))
        } else {
            let num = I0F64::from_str(v)
                .map_err(|e| E::custom(format!("invalid fixed-point number: {}", e)))?;
            Ok(Chance(num))
        }
    }
}

impl<'de> Deserialize<'de> for Chance {
    fn deserialize<D>(deserializer: D) -> Result<Self, D::Error>
    where
        D: Deserializer<'de>,
    {
        deserializer.deserialize_any(ChanceVisitor)
    }
}
