use std::str::FromStr;

use serde::{
    Deserialize, Deserializer,
    de::{Error, MapAccess, Visitor},
};
use uom::si::{
    f64::{Mass, Volume},
    mass::milligram,
    volume::milliliter,
};

use crate::config::{
    cfg,
    utils::{Chance, UnsignedProvider},
};

#[derive(Debug)]
pub struct ItemDef {
    pub id: String,
    pub volume: Volume,
    pub weight: Mass,
    pub container_size: Volume,
}

struct ItemVisitor;
impl<'v> Visitor<'v> for ItemVisitor {
    type Value = ItemDef;

    fn expecting(&self, formatter: &mut std::fmt::Formatter) -> std::fmt::Result {
        formatter.write_str("valid fields are id, container_size")
    }

    fn visit_map<A>(self, mut map: A) -> Result<Self::Value, A::Error>
    where
        A: MapAccess<'v>,
    {
        use serde::de::Error as E;
        let mut id = String::new();
        let mut volume = Volume::new::<milliliter>(0.0);
        let mut weight = Mass::new::<milligram>(0.0);
        let mut container_size = Volume::new::<milliliter>(0.0);
        while let Some(k) = map.next_key::<&str>()? {
            match k {
            "id" => id = map.next_value()?,
            "volume" => volume = Volume::from_str(map.next_value()?).map_err(E::custom)?,
            "weight" => weight = Mass::from_str(map.next_value()?).map_err(E::custom)?,
            "container_size" =>
                container_size = Volume::from_str(map.next_value()?).map_err(E::custom)?,
            _ => {}
            }
        }
        Ok(ItemDef { id, volume, weight, container_size })
    }
}

impl<'de> Deserialize<'de> for ItemDef {
    fn deserialize<D>(deserializer: D) -> Result<Self, D::Error>
    where
        D: Deserializer<'de>,
    {
        deserializer.deserialize_map(ItemVisitor)
    }
}

#[derive(Debug, Clone, Copy)]
pub struct ItemProvider {
    pub idx: usize,
    pub count: UnsignedProvider,
    pub weight: usize,
}

struct ItemProviderVisitor;

impl<'de> Visitor<'de> for ItemProviderVisitor {
    type Value = ItemProvider;

    fn expecting(&self, formatter: &mut std::fmt::Formatter) -> std::fmt::Result {
        formatter.write_str("an item provider")
    }

    fn visit_str<E>(self, v: &str) -> Result<Self::Value, E>
    where
        E: Error,
    {
        let idx = cfg()
            .items
            .iter()
            .position(|i| i.id == v)
            .ok_or_else(|| E::custom("invalid item id"))?;
        Ok(ItemProvider { idx, count: UnsignedProvider::Fixed(1), weight: 1 })
    }

    fn visit_seq<A>(self, seq: A) -> Result<Self::Value, A::Error>
    where
        A: serde::de::SeqAccess<'de>,
    {
        use serde::de::Error as E;
        let mut seq = seq;
        let id = seq.next_element::<&str>()?.ok_or_else(|| E::custom("missing item id"))?;
        let idx = cfg()
            .items
            .iter()
            .position(|i| i.id == id)
            .ok_or_else(|| E::custom("invalid item id"))?;
        let count = seq.next_element::<UnsignedProvider>()?.unwrap_or(UnsignedProvider::Fixed(1));
        let weight = seq.next_element::<usize>()?.unwrap_or(1);
        Ok(ItemProvider { idx, count, weight })
    }

    fn visit_map<A>(self, mut map: A) -> Result<Self::Value, A::Error>
    where
        A: MapAccess<'de>,
    {
        let mut id = String::new();
        let mut count = UnsignedProvider::Fixed(1);
        let mut weight = 1usize;
        while let Some(k) = map.next_key::<&str>()? {
            match k {
            "id" => id = map.next_value()?,
            "count" => count = map.next_value()?,
            "weight" => weight = map.next_value()?,
            _ => {}
            }
        }
        if id.is_empty() {
            return Err(A::Error::custom("missing item id"));
        }
        let idx = cfg()
            .items
            .iter()
            .position(|i| i.id == id)
            .ok_or_else(|| A::Error::custom("invalid item id"))?;
        Ok(ItemProvider { idx, count, weight })
    }
}
impl<'de> Deserialize<'de> for ItemProvider {
    fn deserialize<D>(deserializer: D) -> Result<Self, D::Error>
    where
        D: Deserializer<'de>,
    {
        deserializer.deserialize_any(ItemProviderVisitor)
    }
}

use serde_json::{Value, from_value};

#[derive(Debug)]
pub struct ItemPlaces {
    pub items: Vec<String>,
    pub chance: Chance,
}
struct ItemPlacesVisitor;
impl<'de> serde::de::Visitor<'de> for ItemPlacesVisitor {
    type Value = ItemPlaces;

    fn expecting(&self, formatter: &mut std::fmt::Formatter) -> std::fmt::Result {
        formatter.write_str("an object with items and chance")
    }

    fn visit_map<A>(self, mut map: A) -> Result<Self::Value, A::Error>
    where
        A: serde::de::MapAccess<'de>,
    {
        use serde::de::Error as E;
        let mut items = Vec::new();
        let mut chance = Chance::default();
        while let Some((key, value)) = map.next_entry::<String, Value>()? {
            match key.as_str() {
            "items" => items = from_value(value).map_err(E::custom)?,
            "chance" => chance = from_value(value).map_err(E::custom)?,
            _ => {}
            }
        }
        Ok(ItemPlaces { items, chance })
    }
}
impl<'de> Deserialize<'de> for ItemPlaces {
    fn deserialize<D>(deserializer: D) -> Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        deserializer.deserialize_map(ItemPlacesVisitor)
    }
}
