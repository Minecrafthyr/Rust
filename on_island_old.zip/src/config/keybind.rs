use crossterm::event::KeyCode;
use serde::{Deserialize, de::Visitor};
use serde_json::Value;

use crate::config::NameAndDesc;

#[derive(Debug, Clone)]
pub struct Keybind {
    pub id: String,
    pub key: Vec<KeyCode>,
}

impl NameAndDesc for Keybind {
    const PREFIX: &str = "keybind";

    fn get_id(&self) -> &str { self.id.as_str() }
}

pub fn str_to_keycode(s: &str) -> Option<KeyCode> {
    use KeyCode::*;
    let r = match s.to_ascii_lowercase().as_str() {
    "up" | "↑" => Up,
    "down" | "↓" => Down,
    "left" | "←" => Left,
    "right" | "→" => Right,
    "enter" => Enter,
    "esc" | "escape" => Esc,
    "backspace" => Backspace,
    _ if s.len() == 1 => {
        let ch = s.chars().next().unwrap();
        KeyCode::Char(ch)
    }
    _ => return None,
    };
    Some(r)
}
pub fn keycode_to_string(key: &KeyCode) -> String {
    use KeyCode::*;
    match key {
    Up => "↑".to_string(),
    Down => "↓".to_string(),
    Left => "←".to_string(),
    Right => "→".to_string(),
    Enter => "↵".to_string(),
    Char(c) => c.to_string(),
    _ => format!("{:?}", key),
    }
}
struct KeybindVisitor;
impl<'de> Visitor<'de> for KeybindVisitor {
    type Value = Keybind;

    fn expecting(&self, formatter: &mut std::fmt::Formatter) -> std::fmt::Result {
        formatter.write_str("a keybind object with key, name, and description")
    }

    fn visit_map<A>(self, mut map: A) -> Result<Self::Value, A::Error>
    where
        A: serde::de::MapAccess<'de>,
    {
        use serde::de::Error as E;
        let mut id: String = String::new();
        let mut key: Vec<KeyCode> = vec![];

        while let Some(k) = map.next_key::<&str>()? {
            match k {
            "id" => id = map.next_value()?,
            "key" =>
                key = if let Ok(k) = map.next_value::<String>() {
                    str_to_keycode(&k).map(|kc| vec![kc]).unwrap_or_default()
                } else if let Ok(a) = map.next_value::<Vec<&str>>() {
                    a.into_iter().filter_map(str_to_keycode).collect()
                } else {
                    vec![]
                },
            _ => {}
            }
        }
        if id.is_empty() {
            return Err(E::custom("Missing id field in keybind"));
        }
        Ok(Keybind { id, key })
    }
}

impl<'de> Deserialize<'de> for Keybind {
    fn deserialize<D>(deserializer: D) -> Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        deserializer.deserialize_map(KeybindVisitor)
    }
}
