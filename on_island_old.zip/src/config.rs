use std::{
    borrow::Cow,
    collections::HashMap,
    fmt::Write,
    fs::{self, File},
    path::Path,
    range::Range,
    sync::OnceLock,
};

use crate::{
    config::{
        item::{ItemDef, ItemPlaces, ItemProvider},
        keybind::Keybind,
    },
    io_err,
};

pub trait NameAndDesc {
    const PREFIX: &str;
    fn get_id(&self) -> &str;
    fn name(&self) -> Cow<'static, str> { t!(format!("{}.{}.name", self.get_id(), Self::PREFIX)) }
    fn description(&self) -> Cow<'static, str> {
        t!(format!("{}.{}.description", self.get_id(), Self::PREFIX))
    }
}
pub mod item;
pub mod keybind;

use serde_json::Value;
pub mod utils;

#[derive(Debug, Default)]
pub struct Config {
    pub items: Vec<ItemDef>,
    pub keybinds: HashMap<String, Keybind>,
    pub itemgroups: HashMap<String, Vec<ItemProvider>>,
    pub itemplaces: HashMap<String, ItemPlaces>,
}
macro_rules! serde_yaml {
    ($file:expr $(,)?) => {
        serde_saphyr::from_str(include_str!($file)).map_err(|e| io_err!(Other, e))
    };
}
impl Config {
    fn init_keybinds(&mut self) -> std::io::Result<()> {
        let value: Value = serde_yaml!("../data/keybinds.yaml")?;
        match value {
        Value::Object(map) =>
            for (k, v) in map {
                let keybind: Keybind = serde_json::from_value(v).map_err(|e| io_err!(Other, e))?;
                self.keybinds.insert(k, keybind);
            },
        _ => return Err(io_err!(Other, "keybinds.yaml is not an object")),
        }
        Ok(())
    }

    fn init_itemgroups(&mut self) -> std::io::Result<()> {
        let value: Value = serde_yaml!("../data/itemgroups.yaml")?;
        match value {
        Value::Object(map) =>
            for (k, v) in map {
                let providers: Vec<ItemProvider> =
                    serde_json::from_value(v).map_err(|e| io_err!(Other, e))?;
                self.itemgroups.insert(k, providers);
            },
        _ => return Err(io_err!(Other, "itemgroups.yaml is not an object")),
        }
        Ok(())
    }

    fn init_itemplaces(&mut self) -> std::io::Result<()> {
        let value: Value = serde_yaml!("../data/itemplaces.yaml")?;
        match value {
        Value::Object(map) =>
            for (k, v) in map {
                let itemplaces: ItemPlaces =
                    serde_json::from_value(v).map_err(|e| io_err!(Other, e))?;
                self.itemplaces.insert(k, itemplaces);
            },
        _ => return Err(io_err!(Other, "itemplaces.yaml is not an object")),
        }
        Ok(())
    }
}
impl Config {
    pub fn new() -> std::io::Result<Self> {
        let mut r = Self::default();
        r.items = serde_yaml!("../data/items.yaml")?;
        r.init_keybinds()?;
        r.init_itemgroups()?;
        r.init_itemplaces()?;
        Ok(r)
    }
}
static CONFIG: OnceLock<Config> = OnceLock::new();
pub fn cfg() -> &'static Config { CONFIG.get().expect("Config not inited!") }
pub fn init_config() -> std::io::Result<()> {
    let cfg = Config::new()?;
    CONFIG.get_or_init(|| cfg);
    Ok(())
}
