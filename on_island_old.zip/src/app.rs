use std::io::{Stdout, stdout};

use crossterm::{
    execute,
    terminal::{EnterAlternateScreen, enable_raw_mode},
};
use glam::DVec3;
use ratatui::{Terminal, backend::CrosstermBackend};

use crate::{config::init_config, item::Item};
pub struct App {
    pub terminal: Terminal<CrosstermBackend<Stdout>>,
    pub resources: Vec<(DVec3, Item)>,
}
impl App {
    pub fn new() -> std::io::Result<Self> {
        init_config()?;
        enable_raw_mode()?;
        let mut stdout = stdout();
        execute!(stdout, EnterAlternateScreen)?;
        let backend = CrosstermBackend::new(stdout);
        Ok(Self { terminal: Terminal::new(backend)?, resources: vec![] })
    }

    pub fn run(&mut self) -> std::io::Result<()> { Ok(()) }
}
