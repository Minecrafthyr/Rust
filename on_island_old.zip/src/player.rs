use uom::{
    ConstZero,
    si::{f64::*, mass::kilogram, ratio::basis_point, volume::liter},
};

use crate::item::{Item, ItemStack};

pub struct Player {
    strength: f64,
    inventory: Vec<ItemStack>,
    inventory_volume_used: Volume,
    inventory_weight: Mass,
    worn: Vec<Item>,
}
impl Player {
    pub fn max_carry_weight(&self) -> Mass { self.strength * Mass::new::<kilogram>(10.0) }

    pub fn max_carry_volume(&self) -> Volume {
        Volume::new::<liter>(10.0) + self.worn.iter().fold(Volume::ZERO, |v, i| v + i.volume)
    }

    pub fn insert_item(&mut self, i: Item) -> Option<Item> {
        let new_volume = self.inventory_volume_used + i.volume;
        if !(new_volume < self.max_carry_volume()) {
            return Some(i);
        };
        let new_weight = self.inventory_weight + i.weight;
        if !(new_weight < self.max_carry_weight()) {
            return Some(i);
        };
        if let Some(ei) = self.inventory.iter_mut().find(|ei| ei.item == i) {
            ei.count += 1;
        } else {
            self.inventory.push(ItemStack { item: i, count: 1 });
        }
        self.inventory_volume_used = new_volume;
        self.inventory_weight = new_weight;
        None
    }

    pub fn insert_item_stack(&mut self, i: ItemStack) -> Option<ItemStack> {
        let volume_left = self.max_carry_volume() - self.inventory_volume_used;
        let can_hold = (volume_left / i.item.volume).get::<basis_point>() as u64;
        let mut max_count = can_hold;
        if can_hold == 0u64 {
            return Some(i);
        } else if can_hold < i.count {
            max_count = can_hold;
        };
        let weight_left = self.max_carry_weight() - self.inventory_weight;
        let can_hold = (weight_left / i.item.weight).get::<basis_point>() as u64;
        if can_hold == 0u64 {
            return Some(i);
        } else if can_hold < i.count {
            max_count = max_count.min(can_hold);
        };
        self.inventory_volume_used += i.item.volume * max_count as f64;
        self.inventory_weight += i.item.weight * max_count as f64;
        if let Some(ei) = self.inventory.iter_mut().find(|ei| ei.item == i.item) {
            ei.count += max_count;
        } else {
            self.inventory.push(ItemStack { item: i.item.clone(), count: max_count });
        }
        if i.count != max_count {
            return Some(ItemStack { item: i.item, count: i.count - max_count });
        }
        None
    }
}
